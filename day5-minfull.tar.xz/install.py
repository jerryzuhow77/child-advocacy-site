from pathlib import Path
import shutil, json
root=Path('.')
payload=Path(__file__).resolve().parent
for path in payload.rglob('*'):
    if not path.is_file() or path.name=='install.py': continue
    rel=path.relative_to(payload)
    dest=root/rel
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dest)
# index merge
def merge(path, item):
    p=root/path
    data=json.loads(p.read_text()) if p.exists() else []
    data=[x for x in data if x.get('url')!=item['url']]
    data.append(item)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
merge(Path('data/hearing-records.json'),{
'date':'2025-04-29','title':'剴剴案｜第五日・第五次審判期日','court':'臺北地方法院｜國民法官審理','summary':'許倬憲法醫師與呂立醫師作證；整理法醫死因研判、兒少保護醫療鑑定、PMCT、營養不良、傷勢與完整庭上問答。','image':'../assets/art/prison-watch-day4-hearing-poster-clay-20260821-v2.webp','url':'prison-watch/kaikai-day5-20250429/','caseUrl':'../cases/kaikai/'})
merge(Path('en/data/hearing-records.json'),{
'date':'2025-04-29','title':'KaiKai case | Day 5 · Fifth Trial Hearing','court':'Taipei District Court｜Citizen-Judge Trial','summary':'Medical testimony from forensic pathologist Hsu Cho-hsien and child-protection physician Lu Li, with the complete courtroom record.','image':'../../assets/art/prison-watch-day4-hearing-poster-clay-20260821-v2.webp','url':'prison-watch/kaikai-day5-20250429/','caseUrl':'../cases/kaikai/'})
merge(Path('ja/data/hearing-records.json'),{
'date':'2025-04-29','title':'剴剴事件｜第5日・第5回公判期日','court':'台北地方法院｜国民法官審理','summary':'許倬憲法医師と呂立医師の医学鑑定証言、および法廷での全問答を再構成した記録。','image':'../../assets/art/prison-watch-day4-hearing-poster-clay-20260821-v2.webp','url':'prison-watch/kaikai-day5-20250429/','caseUrl':'../cases/kaikai/'})
# sitemap
sp=root/'sitemap.xml'
if sp.exists():
 t=sp.read_text()
 entries=['https://jerryzuhow77.github.io/child-advocacy-site/hearing-records/prison-watch/kaikai-day5-20250429/','https://jerryzuhow77.github.io/child-advocacy-site/en/hearing-records/prison-watch/kaikai-day5-20250429/','https://jerryzuhow77.github.io/child-advocacy-site/ja/hearing-records/prison-watch/kaikai-day5-20250429/']
 add=''.join(f'  <url>\n    <loc>{u}</loc>\n    <lastmod>2026-08-22</lastmod>\n  </url>\n' for u in entries if u not in t)
 if add: sp.write_text(t.replace('</urlset>',add+'</urlset>'))

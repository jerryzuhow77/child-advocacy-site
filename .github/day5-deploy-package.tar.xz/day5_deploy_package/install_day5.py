#!/usr/bin/env python3
"""Install the Day 5 medical-testimony page into child-advocacy-site.
Run from the repository root. This script is merge-only and idempotent.
"""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

ROOT = Path.cwd()
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"
DAY5_URL = "prison-watch/kaikai-day5-20250429/"
PUBLIC_PATH = "hearing-records/prison-watch/kaikai-day5-20250429/"

if not (ROOT / ".git").exists():
    raise SystemExit("Run this installer from the child-advocacy-site repository root.")

# 1. Copy new/updated public files.
for src in PAYLOAD.rglob("*"):
    if not src.is_file():
        continue
    rel = src.relative_to(PAYLOAD)
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

entries = {
    "zh": {
        "date": "2025-04-29",
        "title": "剴剴案｜第五日・第五次審判期日",
        "court": "臺北地方法院｜國民法官審理",
        "summary": "許倬憲法醫師、呂立醫師作證；完整呈現法醫死因研判、兒少保護醫療鑑定、PMCT、營養不良、傷勢與兩位醫師證詞對照。",
        "image": "../assets/art/prison-watch-day5-forensic-zh-hant-20260822.webp",
        "url": DAY5_URL,
        "caseUrl": "../cases/kaikai/",
    },
    "en": {
        "date": "2025-04-29",
        "title": "KaiKai Case | Day 5 · Fifth Trial Hearing",
        "court": "Taipei District Court | Citizen Judges",
        "summary": "Forensic physician Hsu Cho-hsien and child-protection physician Lu Li testified. The page preserves the full hearing record and compares their methods, death-cause framing, imaging evidence, injury assessment and limits.",
        "image": "../../assets/art/prison-watch-day5-forensic-zh-hant-20260822.webp",
        "url": DAY5_URL,
        "caseUrl": "../cases/kaikai/",
    },
    "ja": {
        "date": "2025-04-29",
        "title": "剴剴事件｜第5日・第5回公判期日",
        "court": "台北地方裁判所｜国民法官審理",
        "summary": "許倬憲法医師と呂立医師が証言。法医死因鑑定、児童保護医療、PMCT、栄養不良、傷害、両医師の証言照合と完全な傍聴記録を掲載。",
        "image": "../../assets/art/prison-watch-day5-forensic-zh-hant-20260822.webp",
        "url": DAY5_URL,
        "caseUrl": "../cases/kaikai/",
    },
}

# 2. Add hearing-record index entries after Day 4, without duplicating.
def update_records(path: Path, entry: dict) -> None:
    if not path.exists():
        return
    data = json.loads(path.read_text(encoding="utf-8"))
    if any(item.get("url") == DAY5_URL for item in data):
        return
    insert_at = len(data)
    for i, item in enumerate(data):
        if item.get("url") == "prison-watch/kaikai-day4-20250428/":
            insert_at = i + 1
            break
    data.insert(insert_at, entry)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

for path, lang in [
    (ROOT / "data/hearing-records.json", "zh"),
    (ROOT / "en/data/hearing-records.json", "en"),
    (ROOT / "ja/data/hearing-records.json", "ja"),
    (ROOT / "source/data/hearing-records.json", "zh"),
    (ROOT / "source/en/data/hearing-records.json", "en"),
    (ROOT / "source/ja/data/hearing-records.json", "ja"),
]:
    update_records(path, entries[lang])

# 3. Add search index item.
def update_search(path: Path) -> None:
    if not path.exists():
        return
    data = json.loads(path.read_text(encoding="utf-8"))
    items = data.setdefault("items", [])
    url = PUBLIC_PATH
    if not any(item.get("url") == url for item in items):
        items.insert(0, {
            "title": "剴剴案｜第五日・第五次審判期日",
            "category": "旁聽紀錄・剴剴案",
            "url": url,
            "date": "2026-08-22",
            "summary": "2025年4月29日第五次審判期日：許倬憲法醫師與呂立醫師作證，完整呈現死因研判、傷勢鑑定、PMCT、營養不良、鑑定界線及兩位醫師證詞對照。",
            "keywords": "剴剴案 第五日 第五次審判期日 許倬憲 呂立 法醫 兒少保護醫療 低血容性休克 PMCT 營養不良 42處傷勢 醫學鑑定 證詞對照 完整旁聽紀錄",
            "text": "剴剴案第五日，2025年4月29日第五次審判期日。上午許倬憲法醫師說明法醫鑑定、死亡機轉與死因，下午呂立醫師說明兒少保護醫療、傷勢、PMCT、營養不良與照顧脈絡。專頁並列共同核心、表述差異、互補視角與共同界線，完整保留庭上問答。"
        })
    data["updated"] = "2026-08-22"
    data["count"] = len(items)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

update_search(ROOT / "data/search-index.json")
if (ROOT / "source/data/search-index.json").exists():
    update_search(ROOT / "source/data/search-index.json")

# 4. Add canonical/localized URLs to sitemap.
sitemap = ROOT / "sitemap.xml"
if sitemap.exists():
    text = sitemap.read_text(encoding="utf-8")
    urls = [
        "https://jerryzuhow77.github.io/child-advocacy-site/hearing-records/prison-watch/kaikai-day5-20250429/",
        "https://jerryzuhow77.github.io/child-advocacy-site/en/hearing-records/prison-watch/kaikai-day5-20250429/",
        "https://jerryzuhow77.github.io/child-advocacy-site/ja/hearing-records/prison-watch/kaikai-day5-20250429/",
    ]
    additions = []
    for url in urls:
        if url not in text:
            additions.append(f"  <url>\n    <loc>{url}</loc>\n    <lastmod>2026-08-22</lastmod>\n  </url>\n")
    if additions:
        text = text.replace("</urlset>", "".join(additions) + "</urlset>")
        sitemap.write_text(text, encoding="utf-8")

# 5. Refresh service-worker cache and include Day 5 resources if present.
sw = ROOT / "sw.js"
if sw.exists():
    text = sw.read_text(encoding="utf-8")
    text = re.sub(r"const VERSION = '[^']+';", "const VERSION = '2026-08-22-day5-medical-v1';", text, count=1)
    resources = [
        "./hearing-records/prison-watch/kaikai-day5-20250429/",
        "./hearing-records/prison-watch/kaikai-day5-20250429/day5.css",
        "./hearing-records/prison-watch/kaikai-day5-20250429/day5.js",
        "./assets/art/prison-watch-day5-forensic-zh-hant-20260822.webp",
        "./assets/art/prison-watch-day5-forensic-zh-hans-20260822.webp",
        "./assets/art/prison-watch-day5-medical-zh-hant-20260822.webp",
        "./assets/art/prison-watch-day5-medical-zh-hans-20260822.webp",
    ]
    start = text.find("const APP_SHELL = [")
    end = text.find("];", start)
    if start >= 0 and end >= 0:
        missing = [r for r in resources if r not in text[start:end]]
        if missing:
            before = text[:end].rstrip()
            if not before.endswith(","):
                before += ","
            before += "\n" + ",\n".join(f"  '{r}'" for r in missing) + "\n"
            text = before + text[end:]
    sw.write_text(text, encoding="utf-8")

# 6. Validation.
page = ROOT / PUBLIC_PATH / "index.html"
html = page.read_text(encoding="utf-8")
checks = {
    "comparison heading": "兩位醫師證詞對照專區" in html,
    "comparison cards": html.count("day5-compare-card") >= 7,
    "full record": "完整旁聽紀錄" in html,
    "record chapters": html.count("day5-record-chapter") == 11,
    "expert names": "許倬憲法醫師" in html and "呂立醫師" in html,
}
failed = [name for name, ok in checks.items() if not ok]
if failed:
    raise SystemExit("Validation failed: " + ", ".join(failed))

print("Day 5 installed and validated:")
print(page)

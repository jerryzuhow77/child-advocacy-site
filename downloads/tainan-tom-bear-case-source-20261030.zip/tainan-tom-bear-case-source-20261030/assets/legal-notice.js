/* Shared legal and source-context notice for article pages. */
(function(){
  'use strict';

  // Route mainland visitors to the complete Hong Kong advocacy mirror. This
  // shared layer is loaded by home, index and article entry points.
  (function redirectMainlandVisitor(){
    if(window.__cpaMainlandMirrorRedirectLoaded)return;
    window.__cpaMainlandMirrorRedirectLoaded=true;
    var mainHost='jerryzuhow77.github.io';
    var mainPrefix='/child-advocacy-site';
    var hongKongBase='https://cn.globalprotectionwall.com/child-advocacy-site';
    if(window.location.hostname!==mainHost)return;
    if(window.location.pathname!==mainPrefix&&window.location.pathname.indexOf(mainPrefix+'/')!==0)return;

    function redirectIfMainland(country){
      if(String(country||'').toUpperCase()!=='CN')return;
      var mirrorPath=window.location.pathname.slice(mainPrefix.length)||'/';
      if(mirrorPath.charAt(0)!=='/')mirrorPath='/'+mirrorPath;
      window.location.replace(hongKongBase+mirrorPath+window.location.search+window.location.hash);
    }

    var cacheKey='cpa-country-code-v1';
    try{
      var cached=window.sessionStorage.getItem(cacheKey);
      if(cached){redirectIfMainland(cached);return;}
    }catch(ignore){}

    var controller=typeof AbortController==='function'?new AbortController():null;
    var timeout=window.setTimeout(function(){if(controller)controller.abort();},3500);
    fetch('https://api.country.is/',{
      method:'GET',mode:'cors',credentials:'omit',cache:'no-store',
      signal:controller?controller.signal:undefined
    }).then(function(response){
      if(!response.ok)throw new Error('country lookup failed');
      return response.json();
    }).then(function(result){
      var country=String(result&&result.country||'').toUpperCase();
      try{if(country)window.sessionStorage.setItem(cacheKey,country);}catch(ignore){}
      redirectIfMainland(country);
    }).catch(function(){
      // Keep the primary site usable when country lookup is unavailable.
    }).then(function(){window.clearTimeout(timeout);});
  })();
  if(window.__cpaLegalNoticeLoaded)return;
  window.__cpaLegalNoticeLoaded=true;
  var path=location.pathname.toLowerCase(),lang=(document.documentElement.lang||'').toLowerCase();
  var type=path.indexOf('/hearing-records/')>-1?'hearing':path.indexOf('/activity-records/')>-1?'activity':path.indexOf('/historical-cases/')>-1?'historical':path.indexOf('/features/social-observation/')>-1?'commentary':(path.indexOf('/cases/')>-1||path.indexOf('/court-comics/')>-1)?'case':'general';
  var copy={
    zh:{boundary:'指控、證詞、當事人陳述、媒體報導、本站推論與法院認定應分別理解；旁聽整理並非法院正式筆錄，時間軸重建不表示所有情節已獲證實。未經判決確定有罪者，應尊重無罪推定；已確定部分與仍有爭議部分應分開閱讀。請勿揭露或拼湊足以識別受保護兒少的資訊，亦勿騷擾、肉搜或散布未經證實的指控。引用與轉載請保留來源、日期及必要上下文，並尊重隱私與著作權；本備註不免除內容本身應負的法律責任。',heading:'法律爭議界限與閱讀備註',common:'本站內容用於公共倡議、資訊整理與教育討論，並非法律意見、訴訟代理意見或對任何人作出的法律判斷。內容依公開判決、司法機關資訊、公開報導及／或授權資料整理；如有更新、更正或不同版本，以可查證的原始資料及主管機關、法院最終公開資訊為準。',hearing:'本頁為旁聽或授權紀錄的整理與版面重製，不是法院正式筆錄、卷證或證物。發言、主張與現場觀察均應回到原始來源及法院程序脈絡理解，不代表法院已採信，亦不應單獨作為事實或責任判斷。',activity:'本頁記錄活動現場、參與者或本站提出的訴求與觀點；引述不代表對相關個人或機構作出事實認定。涉及仍在進行中的案件，其法律責任與事實認定均以法院依法作成的最終裁判為準。',historical:'本頁回顧歷史案件，力求依公開資料整理；案件名稱、人物稱呼與程序結果仍應以可查證的原始資料為準。為保護兒少及相關當事人，請勿轉載、推測或擴散不必要的個人資料。',commentary:'本頁為制度、法律或社會議題的公共討論，不針對特定個案或個人作出定論；法律適用與責任判斷須依具體事實、證據及有權機關的法定程序。',case:'案件中的指控、辯護、證詞、媒體轉述及本站評論，應分別理解，不當然等同已被證明的事實。案件未確定前，應尊重無罪推定及當事人程序權利；刑事責任與事實認定以法院最終裁判為準。',general:'涉及案件、人物或制度的資訊，請連同頁面所載來源與更新時間閱讀；未經證實的說法不應被視為定論或轉傳為事實。'},
    zhHans:{boundary:'指控、证词、当事人陈述、媒体报道、本站推论与法院认定应分别理解；旁听整理并非法院正式笔录，时间轴重建不表示所有情节已获证实。未经判决确定有罪者，应尊重无罪推定；已确定部分与仍有争议部分应分开阅读。请勿揭露或拼凑足以识别受保护儿童的信息，亦勿骚扰、人肉搜索或散布未经证实的指控。引用与转载请保留来源、日期及必要上下文，并尊重隐私与著作权；本备注不免除内容本身应负的法律责任。',heading:'法律争议界限与阅读备注',common:'本站内容用于公共倡议、信息整理与教育讨论，并非法律意见、诉讼代理意见或对任何人作出的法律判断。内容依公开判决、司法机关信息、公开报道及／或授权资料整理；如有更新、更正或不同版本，以可查证的原始资料及主管机关、法院最终公开信息为准。',hearing:'本页为旁听或授权记录的整理与版面重制，不是法院正式笔录、卷证或证物。发言、主张与现场观察均应回到原始来源及法院程序脉络理解，不代表法院已采信，亦不应单独作为事实或责任判断。',activity:'本页记录活动现场、参与者或本站提出的诉求与观点；引述不代表对相关个人或机构作出事实认定。涉及仍在进行中的案件，其法律责任与事实认定均以法院依法作出的最终裁判为准。',historical:'本页回顾历史案件，力求依公开资料整理；案件名称、人物称呼与程序结果仍应以可查证的原始资料为准。为保护儿童及相关当事人，请勿转载、推测或扩散不必要的个人资料。',commentary:'本页为制度、法律或社会议题的公共讨论，不针对特定个案或个人作出定论；法律适用与责任判断须依具体事实、证据及有权机关的法定程序。',case:'案件中的指控、辩护、证词、媒体转述及本站评论，应分别理解，不当然等同已被证明的事实。案件未确定前，应尊重无罪推定及当事人程序权利；刑事责任与事实认定以法院最终裁判为准。',general:'涉及案件、人物或制度的信息，请连同页面所载来源与更新时间阅读；未经证实的说法不应被视为定论或转传为事实。'},
    en:{boundary:'Distinguish allegations, testimony, party statements, media reports, our inferences and court findings. Hearing observations are not official transcripts; reconstructed timelines do not establish every event as fact. Respect the presumption of innocence for persons without a final conviction, and distinguish final findings from unresolved issues. Do not disclose or piece together information identifying protected children, harass or dox anyone, or spread unverified accusations. Quotations and republication should preserve sources, dates and necessary context and respect privacy and copyright. This notice does not exempt the content from legal responsibility.',heading:'Reading & legal-status note',common:'This site is for public advocacy, information organisation and education. It is not legal advice, litigation advice, or a legal determination about any person. Verifiable primary sources and final public information from competent authorities or courts prevail.',hearing:'This page organises observation or authorised hearing records. It is not an official court transcript, case file or exhibit. Statements, submissions and observations must be read in their procedural context; they do not independently establish fact or liability.',activity:'This page records activity and the views or demands of participants or this site. Quotations are not factual findings about any person or organisation. For ongoing matters, facts and legal responsibility remain for the court to determine in its final judgment.',historical:'This historical case summary is compiled from public materials. Names, descriptions and procedural outcomes remain subject to verifiable primary sources. Do not republish, infer or spread unnecessary personal information about children or other persons involved.',commentary:'This page is public discussion of legal, social or institutional issues. It does not determine any individual case or person; legal application and responsibility require facts, evidence and due process.',case:'Allegations, defences, testimony, media reports and this site’s commentary are distinct and do not automatically establish facts. Until a matter is final, the presumption of innocence and procedural rights must be respected. Final court judgments govern facts and criminal liability.',general:'Read case-, person- and institution-related information with the listed sources and update date. Unverified claims must not be treated or shared as established fact.'},
    ja:{boundary:'告発、証言、当事者の陳述、報道、当サイトの推論及び裁判所の認定を区別してください。傍聴記録は正式な調書ではなく、時系列の再構成は全ての出来事の立証を意味しません。有罪が確定していない人の無罪推定を尊重し、確定事項と未解決の争点を区別してください。保護対象の子どもを特定できる情報の公開・照合、嫌がらせ、個人情報の暴露、未確認の告発の拡散は避けてください。引用・転載では出典、日付及び必要な文脈を保ち、プライバシーと著作権を尊重してください。この注記は掲載内容の法的責任を免除するものではありません。',heading:'閲覧・法的状況に関する注記',common:'本サイトは公益的な啓発、情報整理及び教育目的のものであり、法律意見、訴訟代理に関する意見、又は特定の人に対する法的判断ではありません。確認可能な一次資料及び裁判所・主管機関の最終公表情報を優先します。',hearing:'本頁は傍聴又は許諾された記録を整理したもので、裁判所の正式な調書、事件記録又は証拠ではありません。発言・主張・観察は原資料と手続の文脈で理解すべきであり、事実・責任を独自に確定することを意味しません。',activity:'本頁は現場活動、参加者又は当サイトの要望・見解を記録したものです。引用は個人・団体に関する事実認定ではありません。係属中の案件の事実と法的責任は、裁判所の最終判断に従います。',historical:'本頁は公開資料に基づく歴史事件の整理です。名称、表記、手続結果は確認可能な一次資料を優先します。子どもその他関係者の不要な個人情報を転載、推測、拡散しないでください。',commentary:'本頁は制度・法律・社会課題に関する公共的な議論であり、特定の事件又は個人を断定するものではありません。法的評価と責任判断には、具体的な事実、証拠及び適正手続が必要です。',case:'告発、弁護、証言、報道及び当サイトの論評は区別して理解すべきで、直ちに事実の立証を意味しません。確定前の案件では、無罪推定と当事者の手続的権利を尊重し、事実と刑事責任は裁判所の最終判断を基準とします。',general:'事件・人物・制度に関する情報は、掲載された出典と更新日を併せてご確認ください。未確認の主張を確定事実として扱ったり共有したりしないでください。'}
  };
  var text=lang.indexOf('ja')===0?copy.ja:lang.indexOf('en')===0?copy.en:lang.indexOf('zh-hans')===0?copy.zhHans:copy.zh;
  var target=document.querySelector('main')||document.querySelector('article')||document.body;
  if(!target||document.querySelector('[data-cpa-legal-notice]'))return;
  var style=document.createElement('style');
  style.textContent='.cpa-legal-notice{max-width:min(1100px,calc(100% - 32px));margin:24px auto 10px;padding:0;border:1px solid rgba(112,78,31,.28);border-radius:12px;background:#fffaf0;color:#312417;font:400 15px/1.7 system-ui,-apple-system,"Noto Sans TC",sans-serif;box-shadow:0 4px 16px rgba(74,47,19,.06)}.cpa-legal-notice summary{cursor:pointer;padding:13px 16px;font-weight:700;color:#5c3d19;list-style-position:inside}.cpa-legal-notice details>div{padding:0 16px 14px}.cpa-legal-notice p{margin:0}.cpa-legal-notice p+p{margin-top:9px}.cpa-legal-notice summary:focus-visible{outline:3px solid #7b5930;outline-offset:-3px;border-radius:10px}@media(max-width:640px){.cpa-legal-notice{max-width:calc(100% - 20px);margin-top:16px;font-size:14px}.cpa-legal-notice summary{padding:12px}.cpa-legal-notice details>div{padding:0 12px 12px}}';
  document.head.appendChild(style);
  var note=document.createElement('aside');
  note.className='cpa-legal-notice';note.setAttribute('data-cpa-legal-notice','true');note.setAttribute('aria-label',text.heading);
  note.innerHTML='<details open><summary>'+text.heading+'</summary><div><p>'+text.common+'</p><p>'+text[type]+'</p><p>'+text.boundary+'</p></div></details>';
  target.appendChild(note);
}());

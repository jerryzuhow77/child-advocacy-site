# 台南湯姆熊男童命案｜完整靜態頁面備份

建立時間：2026-10-30（Asia/Taipei）  
來源儲存庫：`jerryzuhow77/child-advocacy-site`  
來源提交：`7d757f0184be4f85b133a7c0b660f1c1c915de21`

本壓縮包保留該專題的四個語言頁面，以及所有由這些頁面直接引用的本機 CSS 與 JavaScript：繁體中文、簡體中文、英文、日文、動畫、四語工具列、法律告知和文章留言介面。

## 頁面入口

- `historical-cases/regions/taiwan/tainan-tom-bear-case/index.html`：繁體中文
- `historical-cases/regions/taiwan/tainan-tom-bear-case/zh-Hans/index.html`：簡體中文
- `en/historical-cases/regions/taiwan/tainan-tom-bear-case/index.html`：英文
- `ja/historical-cases/regions/taiwan/tainan-tom-bear-case/index.html`：日文

## 使用方式

為保留原本 `/child-advocacy-site/` 的網址結構，將解壓後的目錄放在網站根目錄的 `child-advocacy-site/` 下，再由該網站根目錄啟動靜態伺服器。例如：

```bash
python3 -m http.server 8080
```

然後開啟：

`http://localhost:8080/child-advocacy-site/historical-cases/regions/taiwan/tainan-tom-bear-case/`

## 範圍與限制

GSAP/ScrollTrigger 動畫函式庫依原頁設定自 jsDelivr 載入；文章瀏覽數與留言仍會使用原站 API。其餘直接引用的靜態頁面資產均已置於本壓縮包。

本備份是原始靜態內容與資產的保存版本，不包含登入憑證、訪客資料或後端資料庫內容。
